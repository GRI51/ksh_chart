// 64分間隔(つまりlength=15間隔)でLASERエフェクトの値を更新する
const EFFECT_INSERTION_INTERVAL = 15;

function execute(chart, ctx) {
  // 選択したレーザーオブジェクトを取得
  const selectedLaserIds = new Set(ctx.selection.laser);

  // 選択範囲内にレーザーがない場合、警告ダイアログを表示して処理を中止
  if (selectedLaserIds.size == 0) {
    WarningDialogJAEN(ctx, "選択範囲内にLASERオブジェクトが存在しません。", "There are no LASER objects within the selected area.");
    return;
  }
  // レーザー音声エフェクトが一切ない場合、警告ダイアログを表示して処理を中止
  if (chart.laserEffectChanges.size == 0) {
    WarningDialogJAEN(ctx, "譜面内にLASERエフェクト変更オブジェクトが存在しません。", "There are no LASER effect change objects in the chart.");
    return;
  }
  // 同一時刻で2つのレーザーを選択しているか判定し、2つ選択している箇所があれば、警告ダイアログを表示して処理を中止
  const overlap_pulse = checkOverlapLaserObj(chart, selectedLaserIds)
  if ( overlap_pulse !== null) {
    measure_id = Chart.measureIdxAt(chart, overlap_pulse) + 1;
    WarningDialogJAEN(ctx, String(measure_id)+"小節目で赤青レーザーが同時に選択されています。レーザーは1つだけ選択してください。処理を中止します。",
                      "Red and blue lasers are simultaneously selected at measure "+String(measure_id)+". Please select only one laser. Processing aborted.");
    return;
  }

  // LASERオブジェクトを順番に探索
  for (let laser_id of selectedLaserIds) {
    let unique_effects = new Set();
    // レーザーオブジェクトを取得
    const laser_obj = Chart.findById(chart.laserSegments, laser_id);
    // 手動で強引にパラメーターを変更 直角レーザーはlaser_obj.length=0なので、ループは実行されない
    for (let delta_y = 0; delta_y < laser_obj.length; delta_y = delta_y + EFFECT_INSERTION_INTERVAL) {
      const y = laser_obj.y + delta_y;
      let laser_pos = calcBezierX(delta_y/laser_obj.length, laser_obj);
      // 赤色レーザーの場合は1の位置が0になるので、0と1を反転させる
      if (laser_obj.lane == 1) {
        laser_pos = 1 - laser_pos;
        laser_pos = laser_pos.toFixed(3)
      }
      // 現在位置に対応するエフェクトの種類を取得
      const effect_name = getLaserEffectNameByY(y, chart);
      unique_effects.add(effect_name);
      const effect_type = getEffectType(chart, effect_name)
      if (effect_type === null) {
        WarningDialogJAEN(ctx, String(effect_name)+"に対応するエフェクト種類が見つかりませんでした。処理を中止します。",
                          "No effect type corresponding to "+String(effect_name)+" was found. Aborting the process.");
        return;
      }
      const param_name = getParamName(effect_type);
      if (param_name === null) {
        // 対象外のエフェクトの場合は、エフェクト変更を追加せずに終了
        continue;
      }
      const effect_value = getEffectValue(effect_type, laser_pos);
      if (effect_value === null) {
        // 対象外のエフェクトの場合は、エフェクト変更を追加せずに終了
        continue;
      }
      // LASERエフェクト変更を書き込み
      addLaserParamChange(chart, {
        y: y,
        effectName: effect_name,
        paramName: param_name,
        value: effect_value,
      });
    }
    for (let unique_effect_name of unique_effects) {
      // LASERの最後の位置でエフェクト定義をリセット
      const effect_type = getEffectType(chart, unique_effect_name);
      const param_name = getParamName(effect_type);
      const init_value = getEffectInitialValue(unique_effect_name, chart);
      if (init_value === null) {
        WarningDialogJAEN(ctx, "カスタムエフェクト「"+String(unique_effect_name)+"」は本スクリプト非対応です。処理を中止します。",
                          String(unique_effect_name)+" not be supported by this script. Aborting the process.");
        return;
      }
      addLaserParamChange(chart, {
        y: laser_obj.y + laser_obj.length,
        effectName: unique_effect_name,
        paramName: param_name,
        value: init_value,
      });
    }
  }
  // 結果をエディタ画面に反映
  Editor.setChart(chart);
}

function getLaserEffectNameByY(y, chart) {
  // yの位置におけるLASERエフェクト定義の名前を返す
  let prev_effect_name = "peaking_filter";

  for (let laser_effect of chart.laserEffectChanges) {
    if (y < laser_effect.y) {
      return prev_effect_name;
    }
    prev_effect_name = laser_effect.effectName;
  }
  return prev_effect_name;
}

// 同じレーザーエフェクト変更がないことを確認してから配列へ追加する
function addLaserParamChange(chart, change) {
  const existingIndex = chart.laserParamChanges.findIndex(existing =>
    existing.y === change.y &&
    existing.effectName === change.effectName &&
    existing.paramName === change.paramName
  );

  // 同じ y + effectName + paramName が存在しない
  if (existingIndex === -1) {
    chart.laserParamChanges.push(change);
    return true;
  }

  const existing = chart.laserParamChanges[existingIndex];

  // 完全に同じ内容なら何もしない
  if (existing.value === change.value) {
    return false;
  }

  // 同じ場所・同じパラメータだが値が違う場合は更新
  chart.laserParamChanges[existingIndex].value = change.value;

  return true;
}

/**
 * `effect_name`に対応するエフェクト種類を取得する。
 * 
 * @param {object} chart
 *   エディタ内部形式の譜面オブジェクト
 *
 * @param {string} effect_name
 *   エフェクトの名前
 */
function getEffectType(chart, effect_name) {
  // カスタムエフェクトに該当するか確認
  for (let laser_effect of chart.laserEffectDefs) {
    if (laser_effect.name == effect_name) {
      return laser_effect.type;
    }
  }
  // 標準搭載エフェクトに該当するか確認
  let regexp = /peaking_filter|high_pass_filter|low_pass_filter|bitcrusher/;
  if (regexp.test(effect_name)) {
    return effect_name;
  }
  // 何にも該当しないのでエラー値としてnullを返す
  return null;
}

/**
 * `effect_type`のパラメーターのうち、LASER位置によって変動するパラメーターを取得する。
 * 
 * @param {string} effect_type
 *   エフェクトの種類
 */
function getParamName(effect_type) {
  switch (effect_type) {
    case "peaking_filter":
      return "v";
    case "high_pass_filter":
      return "v";
    case "low_pass_filter":
      return "v";
    case "bitcrusher":
      return "reduction";
    case "pitch_shift":
      return "pitch";
    default:
      return null; 
  }
}

/**
 * `effect_type`のパラメーターのうち、LASER位置によって変動するパラメーターを取得する。
 * 
 * @param {string} effect_type
 *   エフェクトの種類
 * @param {number} laser_pos
 *   レーザーのX位置（0.0～1.0）
 */
function getEffectValue(effect_type, laser_pos) {
  switch (effect_type) {
    case "peaking_filter":
      return laser_pos;
    case "high_pass_filter":
      return laser_pos;
    case "low_pass_filter":
      return laser_pos;
    case "bitcrusher":
      return String(parseInt(30.0 * laser_pos)) + "samples";
    case "pitch_shift":
      return (12.0 * laser_pos).toFixed(3);
    default:
      return null; 
  }
}

/**
 * `effect_name`の本来定義している値を取得する。
 * 
 * @param {string} effect_name
 *   エフェクトの名前
 * @param {object} chart
 *   エディタ内部形式の譜面オブジェクト
 */
function getEffectInitialValue(effect_name, chart) {
  let params = null;
  let effect_type = null;
  // カスタムエフェクトに該当するか確認
  for (let laser_effect of chart.laserEffectDefs) {
    if (laser_effect.name == effect_name) {
      params = laser_effect.params;
      effect_type = laser_effect.type
      break;
    }
  }
  // 標準搭載エフェクトに該当するか確認
  let regexp = /peaking_filter|high_pass_filter|low_pass_filter/;
  if (regexp.test(effect_name)) {
      return "0%-100%";
  } else if (effect_name == "bitcrusher") {
    return "0samples-30samples";
  }    
  // 見つからなかった場合
  if (params === null) {
    return null
  }
  // 見つかった場合
  switch (effect_type) {
    case "peaking_filter":
      return params.v;
    case "high_pass_filter":
      return params.v;
    case "low_pass_filter":
      return params.v;
    case "bitcrusher":
      return params.reduction;
    case "pitch_shift":
      return params.pitch;
    default:
      // 対応外のエフェクトの場合
      return null; 
  }
}

function checkOverlapLaserObj(chart, laserIds) {
  let exist_pulses = new Set();
  for (let laser_id of laserIds) {
    // LASErオブジェクト取得
    const laser_obj = Chart.findById(chart.laserSegments, laser_id);
    const min_pulse_current = laser_obj.y;
    const max_pulse_current = laser_obj.y + laser_obj.length;
    // 重なりがあるか判定
    for (let e_pulse of exist_pulses) {
      const min_other = e_pulse[0]
      const max_other = e_pulse[1]
      // 重なりが「ない」条件は、
      // 1つ目の最大値 < 2つ目の最小値  または
      // 2つ目の最大値 < 1つ目の最小値
      const noOverlap = max_pulse_current <= min_other || max_other <= min_pulse_current;
      if (!noOverlap){
        // 重なりがある場合は、重なりがあった箇所の小節番号を返す
        return min_pulse_current;
      }
    }
    // 重なりがないので、配列に追加して次のループへ
    exist_pulses.add([min_pulse_current, max_pulse_current]);
  }
  return null;
}


/**
 * LASERのベジェ曲線上で、指定したy座標に対応するx座標を計算する。
 *
 * LASERの曲線は2次ベジェ曲線として扱い、
 * y座標からパラメータ t を二分法で逆算したあと、
 * その t を使ってx座標を求める。
 *
 * @param {number} target_y
 *   0～1に正規化したレーザーのy座標。
 *
 * @param {object} laserSegment
 *   対象となるLASERセグメント。
 *
 * @param {number} epsilon
 *   y座標の誤差をどこまで許容するか。
 *   小さいほど高精度になるが、計算回数が増える可能性がある。
 *   デフォルトは小数第五位までに設定。
 *
 * @param {number} max_iter
 *   二分法による探索の最大反復回数。
 * 　必要な反復回数は、log_2(探索区間の長さ/epsilon)
 * 　log_2(1/1e-5)≒16.6 → デフォルトは17回に設定。
 */
function calcBezierX(target_y, laserSegment, epsilon = 1e-5, max_iter=17) {
  // target_y が曲線の範囲外の場合はnullを返す
  if (target_y < 0 || 1 <target_y) {
      return null;
  }

  const p0 = {"x":laserSegment.startX, "y":0.0}; // 始点
  const p1 = {"x":laserSegment.curve.b * (laserSegment.endX - laserSegment.startX) + laserSegment.startX, "y":laserSegment.curve.a}; // 制御点
  const p2 = {"x":laserSegment.endX, "y":1.0}; // 終点
  let minT = 0;
  let maxT = 1;

  // 二分法で t を探す
  for (let i = 0; i < max_iter; i++) {
      // 2次ベジェ曲線の式から現在の t における y座標を計算
      const t = (minT + maxT) / 2;
      const y =
          (1 - t) * (1 - t) * p0.y +
          2 * (1 - t) * t * p1.y +
          t * t * p2.y;

      // 収束した場合はそこで計算終了
      if (Math.abs(y - target_y) < epsilon) {
          minT = t;
          maxT = t;
          break;
      }

      if (y < target_y) {
          // y が足りないので t を大きくする
          minT = t;
      } else {
          // y が大きすぎるので t を小さくする
          maxT = t;
      }
  }

  // 最終的な探索範囲の中央を、求めた t とする
  const t = (minT + maxT) / 2;

  // 求めた t から x を計算
  x =(1 - t) * (1 - t) * p0.x +
      2 * (1 - t) * t * p1.x +
      t * t * p2.x;
  // 小数点以下3桁に丸めて返す
  return x.toFixed(3)
}

function WarningDialogJAEN(ctx, japanese_message, english_message){
  switch (ctx.language) {
    case "ja":
      Dialog.message("警告", japanese_message);
      break;
    default:
      Dialog.message("Warning", english_message);
  }
}