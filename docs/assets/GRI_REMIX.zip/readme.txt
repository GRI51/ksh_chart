#1 はじめに
GRI REMIX（以下「本パッケージ」）は、GRIが作成した差分譜面をまとめたパッケージです。

#2 プレイに必要なパッケージ
本パッケージをプレイするためには、予め下記パッケージをすべて導入しておく必要があります。
〇Eupholic Selections vol.1
〇Eupholic Selections vol.2
〇SF2016
〇SF2019
〇SF2020
〇SF2022
〇Pastel breeze vol.3

#3 導入方法
「GRI_REMIX」フォルダを、kshootmania.exeと同じディレクトリにある「song」フォルダへ移動してください。

# 問い合わせ先
Twitter:@shallotime
